<?php

do_action('verdure_mikado_style_dynamic');