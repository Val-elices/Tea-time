<?php

verdure_mikado_get_module_template_part('templates/parts/post-type/video', 'blog', '', $params);