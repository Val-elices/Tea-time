<?php verdure_mikado_get_module_template_part( 'templates/parts/search-form', 'search', '', $params ); ?>
<?php verdure_mikado_get_module_template_part( 'templates/parts/loop', 'search', '', $params ); ?>
<?php verdure_mikado_get_module_template_part( 'templates/parts/pagination', 'search', '', $params ); ?>